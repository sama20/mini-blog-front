import { createSlice } from 'redux-starter-kit';
import { combineReducers } from 'redux';

const authSlice = createSlice({
    name: 'auth',
    initialState: {
        isAuthenticated: false,
        user: {}
    },
    reducers: {
        setCurrentUser: (state, action) => {
            state.isAuthenticated = !isEmpty(action.payload);
            state.user = action.payload;
        },
    }
});

const rootReducer = combineReducers({
    auth: authSlice.reducer,
});

export default rootReducer;
