import axios from "axios";
import authHeader from "./auth-header";

const API_URL = "http://blog.test/api/";

const getPublicContent = () => {
    return axios.get(API_URL + "all");
};

// const createPost = () => {
//     return axios.post(API_URL + "all");
// };

const getUserBoard = () => {
    return axios.get(API_URL + "user", { headers: authHeader() });
};

const getModeratorBoard = () => {
    return axios.get(API_URL + "mod", { headers: authHeader() });
};

const getAdminBoard = () => {
    return axios.get(API_URL + "admin", { headers: authHeader() });
};

const createPost = (data) => {
    return axios.post(API_URL + "posts", {...data},{ headers: authHeader() });
};

export default {
    getPublicContent,
    getUserBoard,
    getModeratorBoard,
    getAdminBoard,
    createPost,
};
