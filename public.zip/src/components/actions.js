import axios from 'axios';
import { toast } from 'react-toastify';
import { LOGIN, LOGOUT, REGISTER, REFRESH, ME } from './types';
import setAuthToken from '../utils/setAuthToken';

export const login = (userData) => async (dispatch) => {
    try {
        const res = await axios.post('/api/login', userData);
        const { token } = res.data;

        localStorage.setItem('jwtToken', token);
        setAuthToken(token);

        dispatch({
            type: LOGIN,
            payload: res.data,
        });
    } catch (err) {
        toast.error(err.response.data.message);
    }
};

export const logout = () => (dispatch) => {
    localStorage.removeItem('jwtToken');
    setAuthToken(false);
    dispatch({
        type: LOGOUT,
    });
};

export const refresh = () => async (dispatch) => {
    try {
        const res = await axios.post('/api/refresh');
        const { token } = res.data;

        localStorage.setItem('jwtToken', token);
        setAuthToken(token);

        dispatch({
            type: REFRESH,
            payload: res.data,
        });
    } catch (err) {
        toast.error(err.response.data.message);
    }
};

export const register = (userData) => async (dispatch) => {
    try {
        const res = await axios.post('/api/register', userData);

        localStorage.setItem('jwtToken', res.data.token);
        setAuthToken(res.data.token);

        dispatch({
            type: REGISTER,
            payload: res.data,
        });
    } catch (err) {
        toast.error(err.response.data.message);
    }
};

export const getMe = () => async (dispatch) => {
    try {
        const res = await axios.get('/api/me');

        dispatch({
            type: ME,
            payload: res.data,
        });
    } catch (err) {
        toast.error(err.response.data.message);
    }
};
