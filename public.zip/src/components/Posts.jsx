import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Posts = () => {
    const [posts, setPosts] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            try {
                const result = await axios.get('http://blog.test/api/posts');
                setPosts(result.data);
            } catch (err) {
                setError(err);
            }
            setLoading(false);
        };
        fetchData();
    }, []);

    if (loading) return <p>Loading...</p>;
    if (error) return <p>An error occurred: {error.message}</p>;

    return (

            <ul className="list-group">
                {posts.map(post => (
                    <li className="list-group-item" key={post.id}>
                        <h2 className="mb-3">{post.title}</h2>
                        <p className="mb-0">{post.content}</p>
                    </li>
                ))}
            </ul>



    );
};

export default Posts;
